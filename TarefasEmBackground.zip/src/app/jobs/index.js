export { default as RegistrationMail } from './RegistrationMail';
